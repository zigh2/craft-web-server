#!/usr/bin/env sh
cd "$(dirname "$0")" && exec python3 server.py --setup-https "$@"
